/** Webtoon Work Timer - Google Sheets sync endpoint
 * Deploy as Web app: Execute as Me, access Anyone (or your organization, if supported).
 * Put the same SYNC_KEY in the Windows app settings.
 * Existing LOG sheet layout A:I is preserved; column J stores unique sync IDs.
 */
const SYNC_KEY = 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET';
const LOG_SHEET = '로그';

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (body.key !== SYNC_KEY) return json_({ok:false, error:'Unauthorized: 공유 키가 일치하지 않습니다.'});
    if (body.action !== 'sync' || !Array.isArray(body.records)) return json_({ok:false,error:'잘못된 요청입니다.'});
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sh = ss.getSheetByName(LOG_SHEET);
    if (!sh) {
      sh = ss.insertSheet(LOG_SHEET);
      sh.getRange(1,1,1,10).setValues([['날짜','회차','페이지','공정','시작','종료','소요시간','마무리','비고','동기화 ID']]);
      sh.getRange('G2').setFormula('=ARRAYFORMULA(IF(E2:E="",,IF(F2:F="",0,F2:F-E2:E)))');
    } else if (sh.getRange('J1').getValue() !== '동기화 ID') {
      sh.getRange('J1').setValue('동기화 ID');
    }
    const last = sh.getLastRow();
    const known = new Set(last >= 2 ? sh.getRange(2,10,last-1,1).getDisplayValues().flat().filter(String) : []);
    const syncedIds = [];
    body.records.forEach(r => {
      if (!r.id || known.has(String(r.id))) { if (r.id) syncedIds.push(String(r.id)); return; }
      const start = parseDate_(r.start), end = r.end ? parseDate_(r.end) : '';
      const row = Math.max(2, sh.getLastRow()+1);
      sh.getRange(row,1,1,6).setValues([[parseDay_(r.date), Number(r.episode), Number(r.page), String(r.stage || ''), start, end]]);
      sh.getRange(row,8,1,3).setValues([[Boolean(r.finished), String(r.note || ''), String(r.id)]]);
      sh.getRange(row,1).setNumberFormat('yyyy-mm-dd');
      sh.getRange(row,5,1,2).setNumberFormat('m/d hh:mm:ss');
      // Existing LOG sheets may use one ARRAYFORMULA in G2; do not overwrite its spill range.
      sh.getRange(row,7).setNumberFormat('[h]:mm:ss');
      known.add(String(r.id)); syncedIds.push(String(r.id));
    });
    return json_({ok:true, syncedIds:syncedIds, count:syncedIds.length});
  } catch (err) {
    return json_({ok:false,error:String(err && err.message || err)});
  }
}
function parseDate_(s) {
  if (!s) return '';
  // App sends local Korean time as yyyy-MM-dd HH:mm:ss. Script timezone should be Asia/Seoul.
  const m = String(s).match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/);
  if (m) return new Date(Number(m[1]),Number(m[2])-1,Number(m[3]),Number(m[4]),Number(m[5]),Number(m[6]));
  return new Date(s);
}
function parseDay_(s) {
  const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  return m ? new Date(Number(m[1]),Number(m[2])-1,Number(m[3])) : new Date(s);
}
function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
