@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -m pip install -r requirements.txt
py -m PyInstaller --noconfirm --clean --windowed --name WebtoonWorkTimer app.py
if errorlevel 1 (echo 빌드 실패. 오류를 확인하세요. & pause & exit /b 1)
echo 완료: dist\WebtoonWorkTimer\WebtoonWorkTimer.exe
pause
