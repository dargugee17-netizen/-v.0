import os, sys, json, csv, sqlite3, threading, time, uuid, shutil, webbrowser
from datetime import datetime, date
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
try:
    import requests
except ImportError:
    requests = None

APP_NAME = 'Webtoon Work Timer'
STAGES = ['데생', '펜터치', '채색', '식자']
BG = '#171a21'; PANEL = '#222733'; PANEL2 = '#2b3240'; TEXT = '#edf1f7'; MUTED = '#9ba6b7'; ACCENT = '#8ab4f8'; GREEN = '#81c995'; RED = '#f28b82'; YELLOW = '#fdd663'

def data_dir():
    base = os.getenv('APPDATA') or str(Path.home())
    p = Path(base) / 'WebtoonWorkTimer'
    p.mkdir(parents=True, exist_ok=True)
    return p

DATA = data_dir(); DB_PATH = DATA / 'worklog.sqlite3'; CONFIG_PATH = DATA / 'config.json'

def stamp(ts=None):
    return datetime.fromtimestamp(ts or time.time()).strftime('%Y-%m-%d %H:%M:%S')

def seconds_text(sec):
    sec = max(0, int(sec or 0)); h, rem = divmod(sec, 3600); m, s = divmod(rem, 60)
    return f'{h:02d}:{m:02d}:{s:02d}'

class Store:
    def __init__(self):
        self.db = sqlite3.connect(DB_PATH)
        self.db.row_factory = sqlite3.Row
        self.db.execute('''CREATE TABLE IF NOT EXISTS logs (
            id TEXT PRIMARY KEY, work_date TEXT NOT NULL, episode INTEGER NOT NULL,
            page INTEGER NOT NULL, stage TEXT NOT NULL, start_ts REAL NOT NULL,
            end_ts REAL, duration_seconds INTEGER NOT NULL DEFAULT 0,
            finished INTEGER NOT NULL DEFAULT 0, note TEXT DEFAULT '', synced INTEGER NOT NULL DEFAULT 0)''')
        self.db.execute('''CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)''')
        self.db.commit()
    def add_segment(self, ep, page, stage, start_ts, end_ts, finished=False, note=''):
        ident = str(uuid.uuid4()); duration = max(0, int((end_ts or time.time()) - start_ts))
        self.db.execute('INSERT INTO logs VALUES (?,?,?,?,?,?,?,?,?,?,?)', (ident, datetime.fromtimestamp(start_ts).strftime('%Y-%m-%d'), ep, page, stage, start_ts, end_ts, duration, int(finished), note, 0))
        self.db.commit(); return ident
    def logs(self, limit=5000):
        return self.db.execute('SELECT * FROM logs ORDER BY start_ts DESC LIMIT ?', (limit,)).fetchall()
    def get(self, ident): return self.db.execute('SELECT * FROM logs WHERE id=?', (ident,)).fetchone()
    def mark_synced(self, ids):
        if ids:
            self.db.executemany('UPDATE logs SET synced=1 WHERE id=?', [(x,) for x in ids]); self.db.commit()
    def pending(self): return self.db.execute('SELECT * FROM logs WHERE synced=0 ORDER BY start_ts').fetchall()
    def setting(self, key, default=''):
        r=self.db.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone(); return r['value'] if r else default
    def set_setting(self, key, value):
        self.db.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,str(value))); self.db.commit()
    def stats(self):
        by_ep=self.db.execute('SELECT episode, SUM(duration_seconds) sec FROM logs GROUP BY episode ORDER BY episode').fetchall()
        by_stage=self.db.execute('SELECT stage, SUM(duration_seconds) sec FROM logs GROUP BY stage ORDER BY stage').fetchall()
        by_day=self.db.execute("SELECT work_date, SUM(duration_seconds) sec FROM logs WHERE work_date >= date('now','-13 day') GROUP BY work_date ORDER BY work_date").fetchall()
        total=self.db.execute('SELECT COALESCE(SUM(duration_seconds),0) FROM logs').fetchone()[0]
        return total, by_ep, by_stage, by_day
    def close(self): self.db.close()

class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title('웹툰 작업 타이머'); self.geometry('1100x760'); self.minsize(940,650); self.configure(bg=BG)
        self.store=Store(); self.started_at=None; self.active=None; self.elapsed_before=0; self.current_log_id=None; self.last_alert=0; self.last_break_alert=0; self._timer_job=None
        self.config_data={}
        try: self.config_data=json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
        except Exception: pass
        self._style(); self._build(); self._restore_timer(); self._refresh_all(); self._tick(); self.protocol('WM_DELETE_WINDOW', self._close)
    def _style(self):
        s=ttk.Style(self); s.theme_use('clam'); s.configure('.', background=BG, foreground=TEXT, fieldbackground=PANEL, bordercolor=PANEL2, font=('Malgun Gothic',10))
        s.configure('TFrame', background=BG); s.configure('Panel.TFrame', background=PANEL); s.configure('TLabel', background=BG, foreground=TEXT); s.configure('Muted.TLabel', background=BG, foreground=MUTED)
        s.configure('Title.TLabel', font=('Malgun Gothic',20,'bold'), foreground=TEXT); s.configure('Big.TLabel', font=('Consolas',38,'bold'), foreground=ACCENT); s.configure('Section.TLabel', font=('Malgun Gothic',12,'bold'), foreground=TEXT)
        s.configure('TButton', padding=(12,8), background=PANEL2, foreground=TEXT); s.map('TButton', background=[('active','#3b4558')])
        s.configure('Accent.TButton', background='#355b91', foreground='white'); s.map('Accent.TButton', background=[('active','#4775b3')])
        s.configure('Treeview', background=PANEL, fieldbackground=PANEL, foreground=TEXT, rowheight=27, borderwidth=0); s.configure('Treeview.Heading', background=PANEL2, foreground=TEXT, font=('Malgun Gothic',9,'bold')); s.map('Treeview', background=[('selected','#355b91')], foreground=[('selected','white')])
        s.configure('TNotebook', background=BG, borderwidth=0); s.configure('TNotebook.Tab', background=PANEL2, foreground=TEXT, padding=(14,8)); s.map('TNotebook.Tab', background=[('selected','#355b91')])
        s.configure('TCombobox', fieldbackground=PANEL2, background=PANEL2, foreground=TEXT, arrowcolor=TEXT); s.configure('TEntry', fieldbackground=PANEL2, foreground=TEXT)
    def _build(self):
        top=ttk.Frame(self, padding=(22,18,22,8)); top.pack(fill='x')
        ttk.Label(top,text='WEBTOON  /  WORKSPACE',style='Muted.TLabel').pack(anchor='w')
        ttk.Label(top,text='작업시간 타이머',style='Title.TLabel').pack(anchor='w',pady=(2,0))
        self.status=tk.StringVar(value='● 로컬 저장 활성화'); ttk.Label(top,textvariable=self.status,foreground=GREEN).pack(anchor='e')
        self.tabs=ttk.Notebook(self); self.tabs.pack(fill='both',expand=True,padx=20,pady=(8,20))
        self.timer_tab=ttk.Frame(self.tabs,padding=18); self.history_tab=ttk.Frame(self.tabs,padding=16); self.stats_tab=ttk.Frame(self.tabs,padding=16); self.settings_tab=ttk.Frame(self.tabs,padding=16)
        self.tabs.add(self.timer_tab,text='타이머'); self.tabs.add(self.history_tab,text='작업 기록'); self.tabs.add(self.stats_tab,text='통계'); self.tabs.add(self.settings_tab,text='설정 · 백업')
        self._build_timer(); self._build_history(); self._build_stats(); self._build_settings()
    def _build_timer(self):
        main=ttk.Frame(self.timer_tab); main.pack(fill='both',expand=True)
        left=ttk.Frame(main,style='Panel.TFrame',padding=22); left.pack(side='left',fill='both',expand=True,padx=(0,12))
        ttk.Label(left,text='CURRENT SESSION',background=PANEL,foreground=MUTED).pack(anchor='w')
        self.timer_text=ttk.Label(left,text='00:00:00',style='Big.TLabel',background=PANEL); self.timer_text.pack(anchor='w',pady=(18,5))
        self.timer_state=tk.StringVar(value='작업 대기 중'); ttk.Label(left,textvariable=self.timer_state,background=PANEL,foreground=MUTED).pack(anchor='w')
        ttk.Separator(left).pack(fill='x',pady=22)
        form=ttk.Frame(left,style='Panel.TFrame'); form.pack(fill='x')
        self.ep_var=tk.StringVar(value='1'); self.page_var=tk.StringVar(value='1'); self.stage_var=tk.StringVar(value=STAGES[0]); self.note_var=tk.StringVar()
        self._field(form,'회차',self.ep_var,0,0); self._field(form,'페이지',self.page_var,0,1)
        ttk.Label(form,text='공정',background=PANEL,foreground=MUTED).grid(row=2,column=0,sticky='w',pady=(14,5))
        ttk.Combobox(form,textvariable=self.stage_var,values=STAGES,state='readonly',width=18).grid(row=3,column=0,sticky='ew',padx=(0,12))
        ttk.Label(form,text='비고 (선택)',background=PANEL,foreground=MUTED).grid(row=2,column=1,sticky='w',pady=(14,5))
        ttk.Entry(form,textvariable=self.note_var).grid(row=3,column=1,sticky='ew')
        form.columnconfigure(0,weight=1); form.columnconfigure(1,weight=1)
        controls=ttk.Frame(left,style='Panel.TFrame'); controls.pack(fill='x',pady=(26,0))
        self.start_btn=ttk.Button(controls,text='▶  시작 / 이어하기',style='Accent.TButton',command=self.start); self.start_btn.pack(side='left',fill='x',expand=True,padx=(0,7))
        self.pause_btn=ttk.Button(controls,text='Ⅱ  일시중지',command=self.pause,state='disabled'); self.pause_btn.pack(side='left',fill='x',expand=True,padx=7)
        self.finish_btn=ttk.Button(controls,text='✓  마무리',command=self.finish,state='disabled'); self.finish_btn.pack(side='left',fill='x',expand=True,padx=(7,0))
        right=ttk.Frame(main,width=260); right.pack(side='right',fill='y'); right.pack_propagate(False)
        self._metric(right,'오늘 작업시간','today_metric'); self._metric(right,'누적 작업시간','total_metric'); self._metric(right,'미동기화 기록','pending_metric')
        ttk.Label(right,text='QUICK ACTIONS',style='Section.TLabel').pack(anchor='w',pady=(20,10))
        ttk.Button(right,text='지금 휴식 시작',command=self.break_start).pack(fill='x',pady=4)
        ttk.Button(right,text='지금 동기화',command=self.sync).pack(fill='x',pady=4)
        ttk.Label(right,text='알림 기준은 설정 탭에서 변경할 수 있어요.',style='Muted.TLabel',wraplength=235).pack(anchor='w',pady=(12,0))
    def _field(self,parent,label,var,row,col):
        ttk.Label(parent,text=label,background=PANEL,foreground=MUTED).grid(row=row,column=col,sticky='w',pady=(0,5))
        ttk.Entry(parent,textvariable=var).grid(row=row+1,column=col,sticky='ew',padx=(0,12) if col==0 else (0,0))
    def _metric(self,parent,label,attr):
        box=ttk.Frame(parent,style='Panel.TFrame',padding=14); box.pack(fill='x',pady=(0,10)); ttk.Label(box,text=label,background=PANEL,foreground=MUTED).pack(anchor='w')
        v=tk.StringVar(value='—'); setattr(self,attr,v); ttk.Label(box,textvariable=v,background=PANEL,font=('Consolas',19,'bold'),foreground=ACCENT).pack(anchor='w',pady=(8,0))
    def _build_history(self):
        bar=ttk.Frame(self.history_tab); bar.pack(fill='x',pady=(0,10)); ttk.Label(bar,text='최근 작업 기록',style='Section.TLabel').pack(side='left'); ttk.Button(bar,text='CSV 내보내기',command=self.export_csv).pack(side='right'); ttk.Button(bar,text='새로고침',command=self._refresh_history).pack(side='right',padx=8)
        cols=('date','ep','page','stage','start','end','duration','finished','sync'); self.history=ttk.Treeview(self.history_tab,columns=cols,show='headings')
        heads={'date':'날짜','ep':'회차','page':'페이지','stage':'공정','start':'시작','end':'종료','duration':'소요시간','finished':'완료','sync':'동기화'}
        widths={'date':95,'ep':55,'page':55,'stage':85,'start':145,'end':145,'duration':95,'finished':60,'sync':80}
        for c in cols: self.history.heading(c,text=heads[c]); self.history.column(c,width=widths[c],anchor='center')
        self.history.pack(fill='both',expand=True)
    def _build_stats(self):
        self.stats_summary=ttk.Label(self.stats_tab,text='',style='Section.TLabel'); self.stats_summary.pack(anchor='w',pady=(0,14))
        area=ttk.Frame(self.stats_tab); area.pack(fill='both',expand=True)
        self.ep_stats=self._stat_table(area,'회차별 누적시간',('회차','시간')); self.stage_stats=self._stat_table(area,'공정별 누적시간',('공정','시간'))
        self.day_stats=self._stat_table(area,'최근 14일 작업량',('날짜','시간'))
        ttk.Label(self.stats_tab,text='그래프는 아래 막대 표시로 비교할 수 있습니다. 각 막대는 해당 목록 내 최댓값 기준입니다.',style='Muted.TLabel').pack(anchor='w',pady=(12,6))
        self.chart=tk.Canvas(self.stats_tab,height=170,bg=PANEL,highlightthickness=0); self.chart.pack(fill='x')
    def _stat_table(self,parent,title,columns):
        box=ttk.Frame(parent,style='Panel.TFrame',padding=10); box.pack(side='left',fill='both',expand=True,padx=(0,8))
        ttk.Label(box,text=title,background=PANEL,font=('Malgun Gothic',10,'bold')).pack(anchor='w',pady=(0,8))
        tree=ttk.Treeview(box,columns=columns,show='headings',height=9)
        for c in columns: tree.heading(c,text=c); tree.column(c,width=95,anchor='center')
        tree.pack(fill='both',expand=True); return tree
    def _build_settings(self):
        ttk.Label(self.settings_tab,text='Google Sheets 연동',style='Section.TLabel').pack(anchor='w',pady=(0,8))
        ttk.Label(self.settings_tab,text='Apps Script 웹 앱 URL과 공유 키를 입력하세요. 연결하지 않아도 모든 기록은 PC에 저장됩니다.',style='Muted.TLabel',wraplength=800).pack(anchor='w',pady=(0,12))
        self.url_var=tk.StringVar(value=self.store.setting('sync_url')); self.key_var=tk.StringVar(value=self.store.setting('sync_key'))
        ttk.Label(self.settings_tab,text='웹 앱 URL').pack(anchor='w'); ttk.Entry(self.settings_tab,textvariable=self.url_var).pack(fill='x',pady=(4,12))
        ttk.Label(self.settings_tab,text='공유 키 (Apps Script와 동일한 값)').pack(anchor='w'); ttk.Entry(self.settings_tab,textvariable=self.key_var,show='•').pack(fill='x',pady=(4,12))
        row=ttk.Frame(self.settings_tab); row.pack(fill='x',pady=(0,20)); ttk.Button(row,text='연결 설정 저장',style='Accent.TButton',command=self.save_settings).pack(side='left'); ttk.Button(row,text='지금 동기화',command=self.sync).pack(side='left',padx=8)
        ttk.Separator(self.settings_tab).pack(fill='x',pady=8)
        ttk.Label(self.settings_tab,text='백업 및 데이터 관리',style='Section.TLabel').pack(anchor='w',pady=(8,10))
        ttk.Label(self.settings_tab,text=f'로컬 데이터베이스 위치: {DB_PATH}',style='Muted.TLabel',wraplength=850).pack(anchor='w',pady=(0,12))
        row2=ttk.Frame(self.settings_tab); row2.pack(anchor='w')
        ttk.Button(row2,text='데이터베이스 백업',command=self.backup).pack(side='left'); ttk.Button(row2,text='CSV 내보내기',command=self.export_csv).pack(side='left',padx=8); ttk.Button(row2,text='Apps Script 코드 보기',command=lambda:webbrowser.open('https://script.google.com/home')).pack(side='left')
        ttk.Label(self.settings_tab,text='장시간 작업 알림과 휴식 알림은 아래 설정에서 조정할 수 있습니다.',style='Section.TLabel').pack(anchor='w',pady=(24,8))
        opts=ttk.Frame(self.settings_tab); opts.pack(anchor='w')
        self.long_var=tk.StringVar(value=self.store.setting('long_hours','2')); self.break_var=tk.StringVar(value=self.store.setting('break_minutes','50')); self.rest_var=tk.StringVar(value=self.store.setting('rest_minutes','10'))
        for label,var in [('장시간 작업 경고 (시간)',self.long_var),('휴식 알림 간격 (작업 분)',self.break_var),('권장 휴식 시간 (분)',self.rest_var)]:
            ttk.Label(opts,text=label).pack(side='left',padx=(0,5)); ttk.Entry(opts,textvariable=var,width=6).pack(side='left',padx=(0,18))
        ttk.Button(opts,text='알림 설정 저장',command=self.save_alert_settings).pack(side='left')
    def _restore_timer(self):
        raw=self.store.setting('active_timer')
        if raw:
            try:
                obj=json.loads(raw); self.active={k:obj[k] for k in ('episode','page','stage','note')}; self.elapsed_before=int(obj.get('elapsed_before',0)); self.started_at=float(obj['started_at']) if obj.get('running') else None
                self.ep_var.set(str(self.active['episode'])); self.page_var.set(str(self.active['page'])); self.stage_var.set(self.active['stage']); self.note_var.set(self.active['note'])
                self.timer_state.set('작업 진행 중 · 복구됨' if self.started_at else '일시중지 · 이어하기 가능'); self.pause_btn.configure(state='normal' if self.started_at else 'disabled'); self.finish_btn.configure(state='normal')
            except Exception: pass
    def _save_active(self):
        obj=None
        if self.active: obj={**self.active,'elapsed_before':self.elapsed_before,'started_at':self.started_at,'running':self.started_at is not None}
        self.store.set_setting('active_timer',json.dumps(obj,ensure_ascii=False) if obj else '')
    def start(self):
        if self.started_at is not None: return
        if self.active is None:
            try: ep=int(self.ep_var.get()); page=int(self.page_var.get())
            except ValueError: messagebox.showerror('입력 확인','회차와 페이지는 숫자로 입력해 주세요.'); return
            if ep<1 or page<1: messagebox.showerror('입력 확인','회차와 페이지는 1 이상이어야 합니다.'); return
            self.active={'episode':ep,'page':page,'stage':self.stage_var.get(),'note':self.note_var.get().strip()}
            if self.active['stage'] not in STAGES: messagebox.showerror('입력 확인','공정을 선택해 주세요.'); self.active=None; return
            self.elapsed_before=0
        self.started_at=time.time(); self.timer_state.set('● 작업 진행 중'); self.start_btn.configure(state='disabled'); self.pause_btn.configure(state='normal'); self.finish_btn.configure(state='normal'); self._save_active(); self._refresh_all()
    def pause(self):
        if self.started_at is None or not self.active: return
        now=time.time(); self.elapsed_before += int(now-self.started_at); self.store.add_segment(self.active['episode'],self.active['page'],self.active['stage'],self.started_at,now,False,self.active['note']); self.started_at=None
        self.timer_state.set('일시중지 · 이어하기 가능'); self.start_btn.configure(state='normal'); self.pause_btn.configure(state='disabled'); self._save_active(); self._refresh_all()
    def finish(self):
        if not self.active: return
        now=time.time()
        if self.started_at is not None:
            self.store.add_segment(self.active['episode'],self.active['page'],self.active['stage'],self.started_at,now,True,self.active['note'])
        else:
            # If paused, write a zero-duration completion marker so the page/stage completion is preserved.
            self.store.add_segment(self.active['episode'],self.active['page'],self.active['stage'],now,now,True,self.active['note']+' (마무리 표시)')
        self.active=None; self.started_at=None; self.elapsed_before=0; self.timer_text.configure(text='00:00:00'); self.timer_state.set('마무리 완료 · 다음 작업을 선택하세요'); self.start_btn.configure(state='normal'); self.pause_btn.configure(state='disabled'); self.finish_btn.configure(state='disabled'); self._save_active(); self._refresh_all(); self.sync(background=True)
    def break_start(self):
        if self.started_at is not None: self.pause()
        messagebox.showinfo('휴식 시작',f'작업 타이머를 일시중지했어요. {self.rest_var.get()}분 정도 휴식해 보세요.')
    def _tick(self):
        if self.started_at is not None:
            sec=self.elapsed_before+int(time.time()-self.started_at); self.timer_text.configure(text=seconds_text(sec))
            try: threshold=float(self.long_var.get())*3600
            except ValueError: threshold=7200
            now=time.time()
            if threshold>0 and sec>=threshold and now-self.last_alert>300:
                self.last_alert=now; self.bell(); self.status.set('⚠ 장시간 작업 중'); self.timer_state.set('⚠ 장시간 작업 중 · 휴식을 고려하세요')
                # Non-blocking warning; avoids interrupting drawing with modal dialogs.
            try: break_seconds=max(1,int(self.break_var.get()))*60
            except (ValueError, AttributeError): break_seconds=3000
            if break_seconds>0 and sec>=break_seconds and now-self.last_break_alert>break_seconds:
                self.last_break_alert=now; self.bell(); self.status.set('☕ 휴식 알림 · 잠시 쉬어가세요')
        else: self.timer_text.configure(text=seconds_text(self.elapsed_before if self.active else 0))
        self._timer_job=self.after(500,self._tick)
    def _refresh_all(self): self._refresh_history(); self._refresh_stats(); self._refresh_metrics()
    def _refresh_history(self):
        if not hasattr(self,'history'): return
        for x in self.history.get_children(): self.history.delete(x)
        for r in self.store.logs(500):
            end=stamp(r['end_ts']) if r['end_ts'] else '진행 중'
            self.history.insert('', 'end', values=(r['work_date'],f"{r['episode']}화",r['page'],r['stage'],stamp(r['start_ts']),end,seconds_text(r['duration_seconds']),'완료' if r['finished'] else '—','완료' if r['synced'] else '대기'))
    def _refresh_metrics(self):
        total, eps, stages, days=self.store.stats(); today=datetime.now().strftime('%Y-%m-%d')
        today_sec=sum(r['duration_seconds'] for r in self.store.logs(5000) if r['work_date']==today)
        self.today_metric.set(seconds_text(today_sec)); self.total_metric.set(seconds_text(total)); self.pending_metric.set(str(len(self.store.pending())))
        if not self.store.pending(): self.status.set('● 로컬 저장 활성화 · 동기화 완료' if self.url_var.get() else '● 로컬 저장 활성화')
    def _refresh_stats(self):
        if not hasattr(self,'stats_summary'): return
        total, eps, stages, days=self.store.stats(); self.stats_summary.configure(text=f'전체 누적 {seconds_text(total)}     ·     회차 {len(eps)}개     ·     최근 14일 기록 {len(days)}일')
        for tree in (self.ep_stats,self.stage_stats,self.day_stats):
            for x in tree.get_children(): tree.delete(x)
        for r in eps: self.ep_stats.insert('','end',values=(f"{r['episode']}화",seconds_text(r['sec'])))
        for r in stages: self.stage_stats.insert('','end',values=(r['stage'],seconds_text(r['sec'])))
        for r in days: self.day_stats.insert('','end',values=(r['work_date'],seconds_text(r['sec'])))
        self.chart.delete('all'); groups=[('공정별',[(r['stage'],r['sec']) for r in stages])]
        w=max(500,self.chart.winfo_width()); y=20
        for label,vals in groups:
            if not vals: self.chart.create_text(15,y,anchor='nw',text='기록이 쌓이면 공정별 그래프가 표시됩니다.',fill=MUTED,font=('Malgun Gothic',10)); continue
            maxv=max(v for _,v in vals) or 1
            for name,val in vals:
                self.chart.create_text(15,y+7,anchor='w',text=name,fill=TEXT,font=('Malgun Gothic',9))
                x0=100; x1=x0+max(2,(w-220)*val/maxv); self.chart.create_rectangle(x0,y,x1,y+15,fill=ACCENT,outline='')
                self.chart.create_text(x1+8,y+7,anchor='w',text=seconds_text(val),fill=MUTED,font=('Consolas',8)); y+=30
    def save_settings(self):
        self.store.set_setting('sync_url',self.url_var.get().strip()); self.store.set_setting('sync_key',self.key_var.get().strip()); self.status.set('● 연결 설정 저장됨'); messagebox.showinfo('설정 저장','구글 시트 연결 설정을 저장했습니다.')
    def save_alert_settings(self):
        try:
            if float(self.long_var.get())<=0 or int(self.break_var.get())<=0 or int(self.rest_var.get())<=0: raise ValueError()
        except ValueError: messagebox.showerror('입력 확인','알림 값은 1 이상의 숫자로 입력해 주세요.'); return
        for k,v in [('long_hours',self.long_var.get()),('break_minutes',self.break_var.get()),('rest_minutes',self.rest_var.get())]: self.store.set_setting(k,v)
        messagebox.showinfo('저장 완료','알림 설정을 저장했습니다. 장시간 작업 경고는 프로그램이 실행 중일 때 표시됩니다.')
    def sync(self,background=False):
        url=self.url_var.get().strip(); key=self.key_var.get().strip()
        if not url:
            if not background: messagebox.showinfo('구글 시트 미연결','설정 탭에서 Apps Script 웹 앱 URL을 먼저 입력해 주세요. 로컬 기록은 안전하게 저장되어 있습니다.')
            return
        if requests is None:
            if not background: messagebox.showerror('모듈 필요','requests 모듈이 설치되지 않았습니다. install.bat을 실행해 주세요.')
            return
        rows=self.store.pending()
        if not rows:
            if not background: messagebox.showinfo('동기화','동기화할 새 기록이 없습니다.')
            return
        payload={'action':'sync','key':key,'records':[{'id':r['id'],'date':r['work_date'],'episode':r['episode'],'page':r['page'],'stage':r['stage'],'start':stamp(r['start_ts']),'end':stamp(r['end_ts']) if r['end_ts'] else '', 'durationSeconds':r['duration_seconds'],'finished':bool(r['finished']),'note':r['note'] or ''} for r in rows]}
        self.status.set('↻ 구글 시트 동기화 중…')
        def worker():
            try:
                response=requests.post(url,json=payload,timeout=25); response.raise_for_status(); result=response.json()
                if not result.get('ok'): raise RuntimeError(result.get('error','알 수 없는 응답'))
                ids=result.get('syncedIds') or [r['id'] for r in rows]; self.after(0,lambda:self._sync_done(ids,len(ids)))
            except Exception as exc: self.after(0,lambda e=str(exc):self._sync_error(e))
        threading.Thread(target=worker,daemon=True).start()
    def _sync_done(self,ids,count): self.store.mark_synced(ids); self.status.set(f'● 동기화 완료 · {count}개 기록'); self._refresh_all();
    def _sync_error(self,error): self.status.set('⚠ 동기화 실패 · 로컬 기록 보존'); messagebox.showwarning('동기화 실패',f'PC 기록은 그대로 보존되어 있어요.\n\n오류: {error}\n\n웹 앱 URL, 공유 키, 배포 권한을 확인해 주세요.')
    def export_csv(self):
        path=filedialog.asksaveasfilename(title='작업 기록 CSV 내보내기',defaultextension='.csv',filetypes=[('CSV 파일','*.csv')],initialfile='webtoon_worklog.csv')
        if not path: return
        rows=self.store.logs(100000)
        with open(path,'w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f); w.writerow(['ID','날짜','회차','페이지','공정','시작','종료','소요시간(초)','마무리','비고','동기화'])
            for r in reversed(rows): w.writerow([r['id'],r['work_date'],r['episode'],r['page'],r['stage'],stamp(r['start_ts']),stamp(r['end_ts']) if r['end_ts'] else '',r['duration_seconds'],bool(r['finished']),r['note'],bool(r['synced'])])
        messagebox.showinfo('내보내기 완료',f'CSV 파일을 저장했습니다.\n{path}')
    def backup(self):
        path=filedialog.asksaveasfilename(title='데이터베이스 백업',defaultextension='.sqlite3',filetypes=[('SQLite 데이터베이스','*.sqlite3')],initialfile='webtoon_worklog_backup.sqlite3')
        if not path: return
        try: shutil.copy2(DB_PATH,path); messagebox.showinfo('백업 완료',f'백업을 저장했습니다.\n{path}')
        except Exception as e: messagebox.showerror('백업 실패',str(e))
    def _close(self):
        self._save_active()
        try:
            if self._timer_job: self.after_cancel(self._timer_job)
        except Exception: pass
        self.store.close(); self.destroy()

if __name__=='__main__':
    App().mainloop()
