@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo =====================================
echo   웹툰 작업시간 타이머 - 설치
 echo =====================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python이 설치되어 있지 않습니다.
  echo https://www.python.org/downloads/windows/ 에서 Python 3.11 이상을 설치하고
  echo 설치 화면에서 Add Python to PATH를 체크한 뒤 다시 실행하세요.
  pause
  exit /b 1
)
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
if errorlevel 1 (echo 설치에 실패했습니다. 인터넷 연결을 확인하세요. & pause & exit /b 1)
echo 설치가 완료되었습니다. run.bat을 실행하세요.
pause
